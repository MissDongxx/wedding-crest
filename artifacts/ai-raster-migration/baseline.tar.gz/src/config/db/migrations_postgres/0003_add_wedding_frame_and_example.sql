CREATE TABLE "wedding-crest"."wedding_example" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"style" text NOT NULL,
	"image_url" text NOT NULL,
	"alt_text" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wedding-crest"."wedding_frame" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"style" text NOT NULL,
	"url" text NOT NULL,
	"thumbnail_url" text,
	"alt_text" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "idx_wedding_example_active_style" ON "wedding-crest"."wedding_example" USING btree ("style","is_active");--> statement-breakpoint
CREATE INDEX "idx_wedding_frame_active_style" ON "wedding-crest"."wedding_frame" USING btree ("style","is_active");
