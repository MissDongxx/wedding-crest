ALTER TABLE "wedding-crest"."wedding_frame"
  ALTER COLUMN "style" DROP NOT NULL;
