CREATE TABLE "wedding-crest"."wedding_asset" (
	"id" text PRIMARY KEY NOT NULL,
	"project_id" text NOT NULL,
	"type" text NOT NULL,
	"url" text NOT NULL,
	"storage_key" text,
	"width" integer DEFAULT 1000 NOT NULL,
	"height" integer DEFAULT 1000 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wedding-crest"."wedding_generation" (
	"id" text PRIMARY KEY NOT NULL,
	"project_id" text NOT NULL,
	"ai_task_id" text,
	"candidate_index" integer NOT NULL,
	"provider" text NOT NULL,
	"model" text NOT NULL,
	"prompt_version" text NOT NULL,
	"style_version" text NOT NULL,
	"layout_version" text NOT NULL,
	"prompt" text NOT NULL,
	"status" text DEFAULT 'queued' NOT NULL,
	"provider_task_id" text,
	"source_image_url" text,
	"final_image_url" text,
	"composed_svg" text,
	"qa_score" integer,
	"cost" integer DEFAULT 0,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wedding-crest"."wedding_generation_review" (
	"id" text PRIMARY KEY NOT NULL,
	"generation_id" text NOT NULL,
	"composition_score" integer NOT NULL,
	"style_score" integer NOT NULL,
	"object_score" integer NOT NULL,
	"negative_space_score" integer NOT NULL,
	"color_score" integer NOT NULL,
	"artifact_score" integer NOT NULL,
	"aesthetic_score" integer NOT NULL,
	"decision" text NOT NULL,
	"review_json" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wedding-crest"."wedding_project" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text,
	"guest_id" text,
	"partner_1" text NOT NULL,
	"partner_2" text NOT NULL,
	"initials" text NOT NULL,
	"wedding_date" text,
	"location" text,
	"venue" text,
	"style" text NOT NULL,
	"layout" text NOT NULL,
	"palette" text NOT NULL,
	"complexity" text DEFAULT 'medium' NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wedding-crest"."wedding_project_element" (
	"id" text PRIMARY KEY NOT NULL,
	"project_id" text NOT NULL,
	"type" text NOT NULL,
	"value" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wedding-crest"."wedding_prompt_template" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"version" text NOT NULL,
	"style" text NOT NULL,
	"template" text NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "wedding-crest"."order" ADD COLUMN "project_id" text;--> statement-breakpoint
ALTER TABLE "wedding-crest"."wedding_asset" ADD CONSTRAINT "wedding_asset_project_id_wedding_project_id_fk" FOREIGN KEY ("project_id") REFERENCES "wedding-crest"."wedding_project"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wedding-crest"."wedding_generation" ADD CONSTRAINT "wedding_generation_project_id_wedding_project_id_fk" FOREIGN KEY ("project_id") REFERENCES "wedding-crest"."wedding_project"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wedding-crest"."wedding_generation_review" ADD CONSTRAINT "wedding_generation_review_generation_id_wedding_generation_id_fk" FOREIGN KEY ("generation_id") REFERENCES "wedding-crest"."wedding_generation"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wedding-crest"."wedding_project" ADD CONSTRAINT "wedding_project_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "wedding-crest"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wedding-crest"."wedding_project_element" ADD CONSTRAINT "wedding_project_element_project_id_wedding_project_id_fk" FOREIGN KEY ("project_id") REFERENCES "wedding-crest"."wedding_project"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_wedding_asset_project_type" ON "wedding-crest"."wedding_asset" USING btree ("project_id","type");--> statement-breakpoint
CREATE INDEX "idx_wedding_generation_project" ON "wedding-crest"."wedding_generation" USING btree ("project_id","status");--> statement-breakpoint
CREATE INDEX "idx_wedding_generation_provider_task" ON "wedding-crest"."wedding_generation" USING btree ("provider","provider_task_id");--> statement-breakpoint
CREATE INDEX "idx_wedding_review_generation" ON "wedding-crest"."wedding_generation_review" USING btree ("generation_id");--> statement-breakpoint
CREATE INDEX "idx_wedding_project_user" ON "wedding-crest"."wedding_project" USING btree ("user_id","status");--> statement-breakpoint
CREATE INDEX "idx_wedding_project_guest" ON "wedding-crest"."wedding_project" USING btree ("guest_id","status");--> statement-breakpoint
CREATE INDEX "idx_wedding_project_element_project" ON "wedding-crest"."wedding_project_element" USING btree ("project_id","type");--> statement-breakpoint
CREATE INDEX "idx_wedding_prompt_active_style" ON "wedding-crest"."wedding_prompt_template" USING btree ("style","active");--> statement-breakpoint
CREATE INDEX "idx_order_project_status" ON "wedding-crest"."order" USING btree ("project_id","status");