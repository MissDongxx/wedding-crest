ALTER TABLE "wedding-crest"."wedding_project" ADD COLUMN "name_display" text DEFAULT 'initials_amp' NOT NULL;--> statement-breakpoint
ALTER TABLE "wedding-crest"."wedding_project" ADD COLUMN "show_date" boolean DEFAULT true NOT NULL;
