ALTER TABLE `wedding_project` ADD COLUMN `typography` text DEFAULT 'editorial_rose' NOT NULL;
