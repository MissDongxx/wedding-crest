PRAGMA foreign_keys=OFF;
--> statement-breakpoint
CREATE TABLE `__new_wedding_frame` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`style` text,
	`url` text NOT NULL,
	`thumbnail_url` text,
	`alt_text` text,
	`is_active` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` integer DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer)) NOT NULL,
	`updated_at` integer DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer)) NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_wedding_frame`
	(`id`, `name`, `style`, `url`, `thumbnail_url`, `alt_text`, `is_active`, `sort_order`, `created_at`, `updated_at`)
SELECT `id`, `name`, `style`, `url`, `thumbnail_url`, `alt_text`, `is_active`, `sort_order`, `created_at`, `updated_at`
FROM `wedding_frame`;
--> statement-breakpoint
DROP TABLE `wedding_frame`;
--> statement-breakpoint
ALTER TABLE `__new_wedding_frame` RENAME TO `wedding_frame`;
--> statement-breakpoint
CREATE INDEX `idx_wedding_frame_active_style` ON `wedding_frame` (`style`,`is_active`);
--> statement-breakpoint
PRAGMA foreign_keys=ON;
