ALTER TABLE `wedding_project` ADD `typography` text DEFAULT 'editorial_rose' NOT NULL;--> statement-breakpoint
ALTER TABLE `wedding_project` ADD `name_display` text DEFAULT 'initials_amp' NOT NULL;--> statement-breakpoint
ALTER TABLE `wedding_project` ADD `show_date` integer DEFAULT true NOT NULL;