CREATE TABLE `wedding_example` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`style` text NOT NULL,
	`image_url` text NOT NULL,
	`alt_text` text,
	`is_active` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` integer DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer)) NOT NULL,
	`updated_at` integer DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer)) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `wedding_frame` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`style` text NOT NULL,
	`url` text NOT NULL,
	`thumbnail_url` text,
	`alt_text` text,
	`is_active` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` integer DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer)) NOT NULL,
	`updated_at` integer DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer)) NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_wedding_example_active_style` ON `wedding_example` (`style`,`is_active`);--> statement-breakpoint
CREATE INDEX `idx_wedding_frame_active_style` ON `wedding_frame` (`style`,`is_active`);
