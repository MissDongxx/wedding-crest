import JSZip from 'jszip';

import { normalizeImageBackgroundToWhite } from '@/shared/lib/pure-image';
import { respErr } from '@/shared/lib/resp';
import { getUserInfo } from '@/shared/models/user';
import {
  getWeddingProject,
  hasPaidWeddingOrder,
  type WeddingGeneration,
} from '@/shared/models/wedding';
import {
  composeWeddingMockups,
  formatWeddingDate,
} from '@/shared/wedding/composer';
import { getWeddingStyle, getWeddingTypography } from '@/shared/wedding/config';
import { buildWeddingTypographyPaths } from '@/shared/wedding/vector-typography';
import {
  appendSvgLayer,
  cropExtractedVector,
  setSvgSize,
  vectorizeWeddingArtwork,
} from '@/shared/wedding/vectorizer';

function fileName(...parts: string[]) {
  return parts
    .join('-')
    .replace(/[^a-zA-Z0-9-_ ]/g, '')
    .replace(/\s+/g, '-')
    .toLowerCase();
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await getUserInfo();
    if (!user) return respErr('sign in is required before download');
    const project = await getWeddingProject(id);
    if (!project || project.userId !== user.id)
      return respErr('project not found');
    if (!(await hasPaidWeddingOrder(user.id, id)))
      return respErr('paid Wedding Identity Pack required');

    const primary =
      project.generations.find(
        (generation: WeddingGeneration) => generation.status === 'selected'
      ) ??
      project.generations.find(
        (generation: WeddingGeneration) => generation.status === 'complete'
      );
    if (!primary?.sourceImageUrl) return respErr('completed crest not found');

    // Recompose everything without the preview watermark for the paid owner.
    const input = { ...project.input, illustrationUrl: primary.sourceImageUrl };
    const style = getWeddingStyle(project.input.style);
    const typography = getWeddingTypography(project.input.typography);
    const mockups = composeWeddingMockups(input);

    // Paid SVG delivery is traced from the actual AI artwork. If the source
    // image is unavailable, stop instead of silently shipping a raster image
    // wrapped in an SVG container.
    const sourceResponse = await fetch(primary.sourceImageUrl);
    if (!sourceResponse.ok) {
      return respErr(
        `could not fetch the AI artwork (${sourceResponse.status})`
      );
    }
    const sourceBuffer = Buffer.from(await sourceResponse.arrayBuffer());
    const normalizedSource = normalizeImageBackgroundToWhite(sourceBuffer);
    if (normalizedSource.checkerboardDetected) {
      return respErr(
        'This older design contains a painted checkerboard. Regenerate it once to create the white-background source before vector delivery.',
        422,
        { reason: 'painted_checkerboard' }
      );
    }
    const vectors = vectorizeWeddingArtwork(normalizedSource.buffer);
    const typographyPaths = await buildWeddingTypographyPaths(
      project.input,
      new URL(request.url).origin,
      project.input.palette[0] || '#292524'
    );
    const blackTypographyPaths = await buildWeddingTypographyPaths(
      project.input,
      new URL(request.url).origin,
      '#000000'
    );
    const typographyScale = `scale(${(vectors.width / 1000).toFixed(6)} ${(vectors.height / 1000).toFixed(6)})`;
    const masterWithTypography = appendSvgLayer(
      vectors.master,
      `<g transform="${typographyScale}">${typographyPaths}</g>`
    );
    const monochromeWithTypography = appendSvgLayer(
      vectors.monochrome,
      `<g transform="${typographyScale}">${blackTypographyPaths}</g>`
    );
    const extractedDetail = cropExtractedVector(
      vectors.master,
      vectors,
      vectors.focus,
      0.46
    );
    const extractedSimplifiedMotif = cropExtractedVector(
      vectors.monochrome,
      vectors,
      vectors.focus,
      0.46
    );

    const zip = new JSZip();
    const folderName = fileName(
      project.partner1,
      project.partner2,
      'Wedding-Crest'
    );
    const folder = zip.folder(folderName)!;

    folder.file('01-primary/primary-crest.svg', masterWithTypography);
    folder.file(
      '01-primary/primary-crest-print-3000.svg',
      setSvgSize(masterWithTypography, 3000)
    );
    folder.file(
      '01-primary/illustration-white-background.png',
      normalizedSource.buffer
    );
    folder.file('02-extracted-detail/crest-detail-color.svg', extractedDetail);
    folder.file(
      '03-simplified/extracted-motif-black.svg',
      extractedSimplifiedMotif
    );
    folder.file(
      '04-black-white/crest-black-vector.svg',
      monochromeWithTypography
    );
    mockups.forEach((mockup) => {
      folder.file(`06-mockups/${fileName(mockup.id)}.svg`, mockup.svg);
    });

    const guide = [
      `${project.partner1} & ${project.partner2} - Wedding Crest Guide`,
      '='.repeat(56),
      '',
      `Wedding date: ${formatWeddingDate(project.weddingDate) || 'not set'}`,
      `Style: ${style.name} (${style.tagline})`,
      `Composition: ${project.layout}`,
      '',
      'Color palette',
      '-------------',
      ...project.input.palette.map((color, index) => `${index + 1}. ${color}`),
      '',
      'Typography',
      '----------',
      `Pairing: ${typography.name}`,
      `Initials font: ${typography.initialsFont.family}`,
      `Names font: ${typography.namesFont.family}`,
      `Date font: ${typography.dateFont.family}`,
      '',
      'Files',
      '-----',
      '01-primary/primary-crest.svg              AI artwork traced to editable color paths',
      '01-primary/primary-crest-print-3000.svg   3000px presentation size; true vector paths',
      '01-primary/illustration-white-background.png  Clean white-background AI artwork',
      '02-extracted-detail/crest-detail-color.svg   Strongest visual motif extracted from the AI artwork',
      '03-simplified/extracted-motif-black.svg      The same extracted motif as monochrome paths',
      '04-black-white/crest-black-vector.svg     Two-color vector for stamps and embossing',
      '06-mockups/                           Stationery mockups',
      '',
      'Usage tips',
      '----------',
      '- Keep clear space around the crest of at least half its height.',
      '- Use your palette colors for invitations and signage.',
      '- The black & white vector is optimized for wax seals and embossing.',
      '- SVG files contain traced paths from your chosen AI design and scale without raster blur.',
    ].join('\n');
    folder.file('05-guide/wedding-crest-guide.txt', guide);

    const archive = await zip.generateAsync({
      type: 'uint8array',
      compression: 'DEFLATE',
    });
    return new Response(Buffer.from(archive), {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${folderName}.zip"`,
      },
    });
  } catch (error) {
    return respErr(error instanceof Error ? error.message : 'download failed');
  }
}
