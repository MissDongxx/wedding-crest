import ImageTracer from 'imagetracerjs';
import jpeg from 'jpeg-js';
import { PNG } from 'pngjs';

const TRACE_MAX_DIMENSION = 640;

interface DecodedImage {
  width: number;
  height: number;
  data: Uint8ClampedArray;
}

export interface WeddingVectorBundle {
  master: string;
  monochrome: string;
  width: number;
  height: number;
  focus: { x: number; y: number };
}

function decodeImage(buffer: Buffer): DecodedImage {
  if (
    buffer.length >= 8 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47
  ) {
    const png = PNG.sync.read(buffer, {
      checkCRC: false,
      skipRescale: true,
    });
    return {
      width: png.width,
      height: png.height,
      data: new Uint8ClampedArray(png.data),
    };
  }

  if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xd8) {
    const image = jpeg.decode(buffer, {
      maxMemoryUsageInMB: 1024,
      useTArray: true,
    });
    return {
      width: image.width,
      height: image.height,
      data: new Uint8ClampedArray(image.data),
    };
  }

  throw new Error('AI artwork must be a PNG or JPEG image');
}

function compositeOnWhite(image: DecodedImage): DecodedImage {
  const data = new Uint8ClampedArray(image.data);
  for (let offset = 0; offset < data.length; offset += 4) {
    const alpha = data[offset + 3] / 255;
    if (alpha < 1) {
      data[offset] = Math.round(data[offset] * alpha + 255 * (1 - alpha));
      data[offset + 1] = Math.round(
        data[offset + 1] * alpha + 255 * (1 - alpha)
      );
      data[offset + 2] = Math.round(
        data[offset + 2] * alpha + 255 * (1 - alpha)
      );
      data[offset + 3] = 255;
    }
  }
  return { ...image, data };
}

function resizeForTracing(image: DecodedImage): DecodedImage {
  const largest = Math.max(image.width, image.height);
  if (largest <= TRACE_MAX_DIMENSION) return image;

  const scale = TRACE_MAX_DIMENSION / largest;
  const width = Math.max(1, Math.round(image.width * scale));
  const height = Math.max(1, Math.round(image.height * scale));
  const data = new Uint8ClampedArray(width * height * 4);

  // Bilinear resampling smooths the tiny raster stair-steps that otherwise
  // become thousands of noisy vector nodes.
  for (let y = 0; y < height; y += 1) {
    const sourceY = ((y + 0.5) * image.height) / height - 0.5;
    const y0 = Math.max(0, Math.floor(sourceY));
    const y1 = Math.min(image.height - 1, y0 + 1);
    const fy = Math.max(0, sourceY - y0);
    for (let x = 0; x < width; x += 1) {
      const sourceX = ((x + 0.5) * image.width) / width - 0.5;
      const x0 = Math.max(0, Math.floor(sourceX));
      const x1 = Math.min(image.width - 1, x0 + 1);
      const fx = Math.max(0, sourceX - x0);
      const target = (y * width + x) * 4;
      const topLeft = (y0 * image.width + x0) * 4;
      const topRight = (y0 * image.width + x1) * 4;
      const bottomLeft = (y1 * image.width + x0) * 4;
      const bottomRight = (y1 * image.width + x1) * 4;
      for (let channel = 0; channel < 4; channel += 1) {
        const top =
          image.data[topLeft + channel] * (1 - fx) +
          image.data[topRight + channel] * fx;
        const bottom =
          image.data[bottomLeft + channel] * (1 - fx) +
          image.data[bottomRight + channel] * fx;
        data[target + channel] = Math.round(top * (1 - fy) + bottom * fy);
      }
    }
  }

  return { width, height, data };
}

function grayscaleThreshold(image: DecodedImage): Uint8ClampedArray {
  const histogram = new Uint32Array(256);
  const luminance = new Uint8Array(image.width * image.height);
  let darkPixelCount = 0;

  for (let pixel = 0; pixel < luminance.length; pixel += 1) {
    const offset = pixel * 4;
    const value = Math.round(
      image.data[offset] * 0.2126 +
        image.data[offset + 1] * 0.7152 +
        image.data[offset + 2] * 0.0722
    );
    luminance[pixel] = value;
    // Ignore the pure-white page when finding the artwork threshold.
    if (value < 248) {
      histogram[value] += 1;
      darkPixelCount += 1;
    }
  }

  let weightedTotal = 0;
  for (let value = 0; value < histogram.length; value += 1) {
    weightedTotal += value * histogram[value];
  }

  let backgroundWeight = 0;
  let backgroundTotal = 0;
  let bestVariance = -1;
  let threshold = 176;
  for (let value = 0; value < histogram.length; value += 1) {
    backgroundWeight += histogram[value];
    if (backgroundWeight === 0) continue;
    const foregroundWeight = darkPixelCount - backgroundWeight;
    if (foregroundWeight === 0) break;
    backgroundTotal += value * histogram[value];
    const backgroundMean = backgroundTotal / backgroundWeight;
    const foregroundMean = (weightedTotal - backgroundTotal) / foregroundWeight;
    const variance =
      backgroundWeight *
      foregroundWeight *
      (backgroundMean - foregroundMean) ** 2;
    if (variance > bestVariance) {
      bestVariance = variance;
      threshold = value;
    }
  }

  // Watercolor artwork can be very pale; keep a useful amount of its linework
  // while still producing a clean two-color stamp/embossing file.
  threshold = Math.min(224, Math.max(138, threshold + 28));
  const output = new Uint8ClampedArray(luminance.length * 4);
  for (let pixel = 0; pixel < luminance.length; pixel += 1) {
    const ink = luminance[pixel] <= threshold ? 0 : 255;
    const offset = pixel * 4;
    output[offset] = ink;
    output[offset + 1] = ink;
    output[offset + 2] = ink;
    output[offset + 3] = 255;
  }
  return output;
}

function findArtworkFocus(image: DecodedImage) {
  const side = Math.min(image.width, image.height) * 0.42;
  const candidates = [
    [0.5, 0.24],
    [0.32, 0.38],
    [0.68, 0.38],
    [0.5, 0.5],
    [0.32, 0.66],
    [0.68, 0.66],
    [0.5, 0.78],
  ];
  let best = { x: image.width / 2, y: image.height / 2, score: -1 };

  for (const [xRatio, yRatio] of candidates) {
    const centerX = image.width * xRatio;
    const centerY = image.height * yRatio;
    const left = Math.max(0, Math.floor(centerX - side / 2));
    const right = Math.min(image.width, Math.ceil(centerX + side / 2));
    const top = Math.max(0, Math.floor(centerY - side / 2));
    const bottom = Math.min(image.height, Math.ceil(centerY + side / 2));
    let score = 0;
    for (let y = top; y < bottom; y += 3) {
      for (let x = left; x < right; x += 3) {
        const offset = (y * image.width + x) * 4;
        const distanceFromWhite = Math.sqrt(
          (255 - image.data[offset]) ** 2 +
            (255 - image.data[offset + 1]) ** 2 +
            (255 - image.data[offset + 2]) ** 2
        );
        if (distanceFromWhite > 28) score += Math.min(180, distanceFromWhite);
      }
    }
    if (score > best.score) best = { x: centerX, y: centerY, score };
  }

  return { x: best.x, y: best.y };
}

function cleanSvg(svg: string, width: number, height: number) {
  return svg
    .replace(/ desc="[^"]*"/g, '')
    .replace(
      '<svg ',
      `<svg width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet" role="img" `
    );
}

export function vectorizeWeddingArtwork(buffer: Buffer): WeddingVectorBundle {
  const image = resizeForTracing(compositeOnWhite(decodeImage(buffer)));
  const focus = findArtworkFocus(image);
  const master = ImageTracer.imagedataToSVG(image, {
    ltres: 1,
    qtres: 1,
    pathomit: 8,
    rightangleenhance: false,
    colorsampling: 1,
    numberofcolors: 24,
    mincolorratio: 0.001,
    colorquantcycles: 3,
    layering: 0,
    strokewidth: 0,
    linefilter: false,
    scale: 1,
    roundcoords: 1,
    viewbox: true,
    desc: false,
    blurradius: 1,
    blurdelta: 24,
  });

  const monochrome = ImageTracer.imagedataToSVG(
    {
      width: image.width,
      height: image.height,
      data: grayscaleThreshold(image),
    },
    {
      ltres: 0.8,
      qtres: 0.8,
      pathomit: 4,
      rightangleenhance: false,
      colorsampling: 0,
      numberofcolors: 2,
      colorquantcycles: 1,
      layering: 0,
      strokewidth: 0,
      linefilter: false,
      scale: 1,
      roundcoords: 1,
      viewbox: true,
      desc: false,
      blurradius: 0,
      blurdelta: 20,
      pal: [
        { r: 255, g: 255, b: 255, a: 255 },
        { r: 0, g: 0, b: 0, a: 255 },
      ],
    }
  );

  return {
    master: cleanSvg(master, image.width, image.height),
    monochrome: cleanSvg(monochrome, image.width, image.height),
    width: image.width,
    height: image.height,
    focus,
  };
}

function svgContents(svg: string) {
  const start = svg.indexOf('>');
  const end = svg.lastIndexOf('</svg>');
  if (start < 0 || end < 0) throw new Error('invalid traced SVG');
  return svg.slice(start + 1, end);
}

export function cropExtractedVector(
  svg: string,
  source: { width: number; height: number },
  center: { x: number; y: number },
  cropRatio: number
) {
  const side = Math.min(source.width, source.height) * cropRatio;
  const x = Math.max(0, Math.min(source.width - side, center.x - side / 2));
  const y = Math.max(0, Math.min(source.height - side, center.y - side / 2));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="${x.toFixed(2)} ${y.toFixed(2)} ${side.toFixed(2)} ${side.toFixed(2)}" preserveAspectRatio="xMidYMid meet" role="img">${svgContents(svg)}</svg>`;
}

export function setSvgSize(svg: string, size: number) {
  return svg.replace(
    /width="[^"]+" height="[^"]+"/,
    `width="${size}" height="${size}"`
  );
}

export function appendSvgLayer(svg: string, layer: string) {
  return svg.replace('</svg>', `${layer}</svg>`);
}
