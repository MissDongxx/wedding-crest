import { create } from 'fontkit';

import { resolveWeddingDisplayTexts } from './composer';
import { getWeddingLayout, getWeddingTypography } from './config';
import type { WeddingProjectInput } from './types';

const FONT_FILES: Record<string, string> = {
  'cormorant garamond': 'cormorant-garamond-common.woff2',
  fraunces: 'fraunces-common.woff2',
  cinzel: 'cinzel-common.woff2',
  manrope: 'manrope-common.woff2',
  'dm sans': 'dm-sans-common.woff2',
  'libre baskerville': 'libre-baskerville-common.woff2',
  'eb garamond': 'eb-garamond-common.woff2',
  'source sans 3': 'source-sans-3-common.woff2',
};

const fontCache = new Map<string, ReturnType<typeof create>>();

async function loadFont(family: string, assetBaseUrl: string) {
  const normalized = family.trim().toLowerCase();
  const file = FONT_FILES[normalized] ?? FONT_FILES['cormorant garamond'];
  const key = `${assetBaseUrl}:${file}`;
  const cached = fontCache.get(key);
  if (cached) return cached;
  const response = await fetch(`${assetBaseUrl}/fonts/wedding/${file}`);
  if (!response.ok) throw new Error(`could not load vector font ${file}`);
  const font = create(Buffer.from(await response.arrayBuffer()));
  fontCache.set(key, font);
  return font;
}

function headlineSize(text: string, base: number) {
  if (text.length <= 8) return base;
  if (text.length <= 12) return base * 0.82;
  if (text.length <= 18) return base * 0.64;
  if (text.length <= 26) return base * 0.5;
  return base * 0.4;
}

async function textAsPaths(
  text: string,
  slot: { x: number; y: number },
  size: number,
  spec: {
    family: string;
    italic?: boolean;
    letterSpacing?: number;
  },
  color: string,
  assetBaseUrl: string,
  opacity = 1,
  maxWidth = 560
) {
  const family =
    spec.italic && spec.family === 'Fraunces' ? 'Fraunces' : spec.family;
  const fileOverride =
    spec.italic && spec.family === 'Fraunces'
      ? 'fraunces-italic-common.woff2'
      : undefined;
  const font = fileOverride
    ? await (async () => {
        const key = `${assetBaseUrl}:${fileOverride}`;
        const cached = fontCache.get(key);
        if (cached) return cached;
        const response = await fetch(
          `${assetBaseUrl}/fonts/wedding/${fileOverride}`
        );
        if (!response.ok)
          throw new Error(`could not load vector font ${fileOverride}`);
        const loaded = create(Buffer.from(await response.arrayBuffer()));
        fontCache.set(key, loaded);
        return loaded;
      })()
    : await loadFont(family, assetBaseUrl);
  const run = font.layout(text);
  let scale = size / font.unitsPerEm;
  const letterSpacing = spec.letterSpacing ?? 0;
  let width =
    run.advanceWidth * scale +
    Math.max(0, run.glyphs.length - 1) * letterSpacing;
  if (width > maxWidth) {
    scale *= maxWidth / width;
    width =
      run.advanceWidth * scale +
      Math.max(0, run.glyphs.length - 1) * letterSpacing;
  }
  const baseline = slot.y + ((run.bbox.maxY + run.bbox.minY) * scale) / 2;
  let cursor = slot.x - width / 2;
  const paths: string[] = [];

  for (let index = 0; index < run.glyphs.length; index += 1) {
    const glyph = run.glyphs[index];
    const position = run.positions[index];
    const x = cursor + position.xOffset * scale;
    const y = baseline - position.yOffset * scale;
    const d = glyph.path.toSVG();
    if (d) {
      paths.push(
        `<path d="${d}" transform="matrix(${scale.toFixed(6)} 0 0 ${(-scale).toFixed(6)} ${x.toFixed(3)} ${y.toFixed(3)})" fill="${color}"${opacity < 1 ? ` opacity="${opacity}"` : ''}/>`
      );
    }
    cursor += position.xAdvance * scale + letterSpacing;
  }

  return paths.join('');
}

export async function buildWeddingTypographyPaths(
  input: WeddingProjectInput,
  assetBaseUrl: string,
  color: string
) {
  const layout = getWeddingLayout(input.layout);
  const typography = getWeddingTypography(input.typography);
  const texts = resolveWeddingDisplayTexts(input);
  const parts = [
    await textAsPaths(
      texts.headline,
      layout.initials,
      headlineSize(texts.headline, 118),
      typography.initialsFont,
      color,
      assetBaseUrl,
      1,
      520
    ),
  ];
  if (texts.names) {
    parts.push(
      await textAsPaths(
        texts.names,
        layout.names,
        texts.names.length > 24 ? 28 : 36,
        typography.namesFont,
        color,
        assetBaseUrl,
        1,
        560
      )
    );
  }
  if (texts.date) {
    parts.push(
      await textAsPaths(
        texts.date,
        layout.date,
        21,
        typography.dateFont,
        color,
        assetBaseUrl,
        0.9,
        500
      )
    );
  }
  return `<g aria-label="Wedding lettering converted to vector paths">${parts.join('')}</g>`;
}
