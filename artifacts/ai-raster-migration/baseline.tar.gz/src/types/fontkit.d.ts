declare module 'fontkit' {
  interface FontPath {
    toSVG(): string;
  }

  interface FontGlyph {
    path: FontPath;
  }

  interface GlyphPosition {
    xAdvance: number;
    xOffset: number;
    yOffset: number;
  }

  interface GlyphRun {
    advanceWidth: number;
    bbox: { minY: number; maxY: number };
    glyphs: FontGlyph[];
    positions: GlyphPosition[];
  }

  export interface Font {
    unitsPerEm: number;
    layout(text: string): GlyphRun;
  }

  export function create(buffer: Uint8Array): Font;
}
