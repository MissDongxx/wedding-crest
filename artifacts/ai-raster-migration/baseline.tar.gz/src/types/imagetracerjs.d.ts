declare module 'imagetracerjs' {
  interface TraceImageData {
    width: number;
    height: number;
    data: Uint8Array | Uint8ClampedArray | number[];
  }

  interface TraceColor {
    r: number;
    g: number;
    b: number;
    a: number;
  }

  interface TraceOptions {
    ltres?: number;
    qtres?: number;
    pathomit?: number;
    rightangleenhance?: boolean;
    colorsampling?: number;
    numberofcolors?: number;
    mincolorratio?: number;
    colorquantcycles?: number;
    layering?: number;
    strokewidth?: number;
    linefilter?: boolean;
    scale?: number;
    roundcoords?: number;
    viewbox?: boolean;
    desc?: boolean;
    blurradius?: number;
    blurdelta?: number;
    pal?: TraceColor[];
  }

  const ImageTracer: {
    imagedataToSVG(
      imageData: TraceImageData,
      options?: TraceOptions | string
    ): string;
  };

  export default ImageTracer;
}
